package com.flowshare.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Le moteur d'envoi, indépendant des écrans : il peut tourner pendant que tu es dans la
 * Galerie Samsung (porté par le service d'accessibilité) ou dans la galerie FlowShare.
 *
 * Cycle : IDLE → ARMED (photo prête, NFC + Bluetooth actifs) → CONNECTING (téléphone collé)
 *         → SENDING → DONE → IDLE.
 */
object SenderEngine {

    enum class State { IDLE, ARMED, CONNECTING, SENDING, DONE, FAILED }
    enum class Source { IN_APP, GALLERY }

    fun interface Listener {
        fun onEngineUpdate(state: State, progress: Float, message: String?)
    }

    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<Listener>()

    var state = State.IDLE
        private set
    var source: Source? = null
        private set

    private var token: String? = null
    private var uri: Uri? = null
    private var endpointId: String? = null
    private var filePayloadId: Long? = null

    /** Branché par le service d'accessibilité : appuie sur Partager › FlowShare dans la Galerie. */
    var shareTrigger: (() -> Unit)? = null

    private val client by lazy { Nearby.getConnectionsClient(app) }
    private val timeout = Runnable { fail(app.getString(R.string.send_timeout)) }

    fun init(context: Context) {
        app = context.applicationContext
    }

    val isBusy: Boolean
        get() = state == State.CONNECTING || state == State.SENDING ||
                state == State.DONE || state == State.FAILED

    /** Vrai quand on a été touché depuis la Galerie Samsung et qu'on attend la photo partagée. */
    val awaitingGalleryUri: Boolean
        get() = source == Source.GALLERY && uri == null &&
                (state == State.ARMED || state == State.CONNECTING)

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    // ---------- Commandes ----------

    fun arm(photo: Uri?, src: Source): Boolean {
        if (isBusy) return false
        if (!Permissions.allGranted(app)) return false
        if (state == State.ARMED) stopRadios()
        val t = ShareSession.start()
        token = t
        uri = photo
        source = src
        endpointId = null
        filePayloadId = null
        setState(State.ARMED)

        val options = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build()
        client.startAdvertising(ShareSession.senderName(t), ShareSession.SERVICE_ID, lifecycleCallback, options)
            .addOnFailureListener { /* le NFC et le Bluetooth restent actifs */ }
        BleProximity.startAdvertising(app, t)
        return true
    }

    /** Change la photo prête (swipe dans la visionneuse) ou fournit celle partagée par la Galerie. */
    fun provideUri(photo: Uri) {
        if (state != State.ARMED && state != State.CONNECTING) return
        uri = photo
        trySend()
    }

    fun disarm(src: Source) {
        if (isBusy || source != src) return
        stopRadios()
        setState(State.IDLE)
    }

    /** Un autre téléphone vient d'être collé (lecture NFC ou demande de connexion Nearby). */
    fun onTouched() {
        if (state != State.ARMED) return
        setState(State.CONNECTING)
        main.removeCallbacks(timeout)
        main.postDelayed(timeout, 25_000)
        if (uri == null) {
            val trigger = shareTrigger
            if (trigger != null) trigger() else fail(app.getString(R.string.send_error))
        }
    }

    fun fail(message: String) {
        main.removeCallbacks(timeout)
        stopRadios()
        setState(State.FAILED, message = message)
        main.postDelayed({ if (state == State.FAILED) setState(State.IDLE) }, 2000)
    }

    // ---------- Interne ----------

    private fun stopRadios() {
        ShareSession.stop()
        token = null
        endpointId = null
        filePayloadId = null
        try {
            client.stopAdvertising()
            client.stopAllEndpoints()
        } catch (_: Exception) {
        }
        BleProximity.stopAdvertising(app)
    }

    private fun setState(s: State, progress: Float = 0f, message: String? = null) {
        state = s
        if (s == State.IDLE) {
            source = null
            uri = null
        }
        // Diffusion asynchrone pour que chaque écouteur reçoive les états dans l'ordre.
        main.post { listeners.forEach { it.onEngineUpdate(s, progress, message) } }
    }

    private val lifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            val t = token
            // On n'accepte que le téléphone qui a reçu NOTRE code (NFC ou Bluetooth).
            if (t != null && info.endpointName == ShareSession.receiverName(t)) {
                client.acceptConnection(id, payloadCallback)
                onTouched()
            } else {
                client.rejectConnection(id)
            }
        }

        override fun onConnectionResult(id: String, resolution: ConnectionResolution) {
            if (resolution.status.isSuccess) {
                endpointId = id
                client.stopAdvertising()
                BleProximity.stopAdvertising(app)
                trySend()
            } else {
                fail(app.getString(R.string.send_error))
            }
        }

        override fun onDisconnected(id: String) {
            if (state == State.CONNECTING || state == State.SENDING) fail(app.getString(R.string.send_error))
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {}

        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {
            if (update.payloadId != filePayloadId) return
            when (update.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS -> {
                    if (update.totalBytes > 0) {
                        setState(State.SENDING, update.bytesTransferred.toFloat() / update.totalBytes)
                    }
                }
                PayloadTransferUpdate.Status.SUCCESS -> {
                    main.removeCallbacks(timeout)
                    setState(State.DONE, 1f)
                    main.postDelayed({
                        if (state == State.DONE) {
                            stopRadios()
                            setState(State.IDLE)
                        }
                    }, 1800)
                }
                PayloadTransferUpdate.Status.FAILURE,
                PayloadTransferUpdate.Status.CANCELED -> fail(app.getString(R.string.send_error))
            }
        }
    }

    private fun trySend() {
        val id = endpointId ?: return
        val photo = uri ?: return
        if (state != State.CONNECTING) return
        val meta = MediaUtils.queryMeta(app, photo)
        val pfd = try {
            app.contentResolver.openFileDescriptor(photo, "r")
        } catch (_: Exception) {
            null
        }
        if (pfd == null) {
            fail(app.getString(R.string.send_error))
            return
        }
        val filePayload = Payload.fromFile(pfd)
        filePayloadId = filePayload.id
        val header = JSONObject()
            .put("name", meta.name)
            .put("mime", meta.mime)
            .put("size", meta.size)
            .put("payloadId", filePayload.id)
            .toString()
        setState(State.SENDING, 0f)
        client.sendPayload(id, Payload.fromBytes(header.toByteArray(Charsets.UTF_8)))
        client.sendPayload(id, filePayload)
    }
}
