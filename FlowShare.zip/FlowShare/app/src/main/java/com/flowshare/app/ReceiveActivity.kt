package com.flowshare.app

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.RenderEffect
import android.graphics.Shader
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Ouvert automatiquement par Android quand on approche un téléphone qui envoie
 * (même si FlowShare était fermé). Retrouve l'expéditeur via Nearby, reçoit la photo,
 * l'enregistre dans la Galerie et la fait "couler" depuis le bord de l'écran.
 */
class ReceiveActivity : ComponentActivity() {

    private lateinit var glow: GlowEdgeView
    private lateinit var card: FrameLayout
    private lateinit var image: ImageView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var buttons: View
    private lateinit var btnOpen: Button

    private var token: String? = null
    private var meta: MediaUtils.Meta? = null
    private var expectedFileId: Long? = null
    private var savedUri: Uri? = null
    private var done = false
    private val files = HashMap<Long, Payload>()

    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val client by lazy { Nearby.getConnectionsClient(this) }
    private val timeout = Runnable { fail(getString(R.string.recv_timeout)) }

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val t = token
            if (Permissions.allGranted(this) && t != null) startDiscovery(t)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receive)
        glow = findViewById(R.id.glow)
        card = findViewById(R.id.card)
        image = findViewById(R.id.image)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        buttons = findViewById(R.id.buttons)
        btnOpen = findViewById(R.id.btnOpen)
        card.clipToOutline = true
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        try {
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (_: Exception) {
        }
        io.shutdown()
    }

    private fun handle(intent: Intent?) {
        val t = parseToken(intent) ?: run { if (token == null) finish(); return }
        if (t == token) return
        // Nouvelle réception : on repart de zéro.
        try {
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (_: Exception) {
        }
        token = t
        meta = null
        expectedFileId = null
        savedUri = null
        done = false
        files.clear()
        card.visibility = View.INVISIBLE
        buttons.visibility = View.INVISIBLE
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = true

        glow.setIntensity(1f)
        glow.startPulse()

        if (Permissions.allGranted(this)) {
            startDiscovery(t)
        } else {
            status.text = getString(R.string.recv_perm)
            buttons.visibility = View.VISIBLE
            btnOpen.visibility = View.VISIBLE
            btnOpen.text = getString(R.string.btn_allow)
            btnOpen.setOnClickListener { askPermissions.launch(Permissions.required()) }
        }
    }

    private fun parseToken(intent: Intent?): String? {
        // Ouvert par le Bluetooth (service d'accessibilité)
        intent?.getStringExtra(ShareSession.EXTRA_TOKEN)?.let { return it }
        // Ouvert par le NFC
        if (intent?.action != NfcAdapter.ACTION_NDEF_DISCOVERED) return null
        val raw: Array<out Parcelable>? =
            if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES, NdefMessage::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)
        raw?.forEach { msg ->
            (msg as? NdefMessage)?.records?.forEach { rec ->
                if (rec.tnf == NdefRecord.TNF_MIME_MEDIA &&
                    String(rec.type, Charsets.US_ASCII) == ShareSession.MIME_TOKEN
                ) {
                    return String(rec.payload, Charsets.UTF_8)
                }
            }
        }
        return null
    }

    // ---------- Nearby ----------

    private fun startDiscovery(t: String) {
        buttons.visibility = View.INVISIBLE
        status.text = getString(R.string.recv_waiting)
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, 20_000)
        val options = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build()
        client.startDiscovery(ShareSession.SERVICE_ID, discoveryCallback, options)
            .addOnFailureListener { e -> fail(getString(R.string.nearby_error, e.message ?: "?")) }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            val t = token ?: return
            if (info.endpointName != ShareSession.senderName(t)) return
            client.stopDiscovery()
            client.requestConnection(ShareSession.receiverName(t), id, lifecycleCallback)
                .addOnFailureListener { e -> fail(getString(R.string.nearby_error, e.message ?: "?")) }
        }

        override fun onEndpointLost(id: String) {}
    }

    private val lifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            client.acceptConnection(id, payloadCallback)
        }

        override fun onConnectionResult(id: String, resolution: ConnectionResolution) {
            if (resolution.status.isSuccess) status.text = getString(R.string.recv_connected)
            else fail(getString(R.string.recv_error))
        }

        override fun onDisconnected(id: String) {
            if (!done) fail(getString(R.string.recv_error))
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> {
                    val bytes = payload.asBytes() ?: return
                    try {
                        val json = JSONObject(String(bytes, Charsets.UTF_8))
                        meta = MediaUtils.Meta(
                            json.optString("name", "photo_${System.currentTimeMillis()}.jpg"),
                            json.optString("mime", "image/jpeg"),
                            json.optLong("size", -1L)
                        )
                        expectedFileId = json.optLong("payloadId")
                    } catch (_: Exception) {
                    }
                }
                Payload.Type.FILE -> files[payload.id] = payload
            }
        }

        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {
            val expected = expectedFileId
            val isFile = files.containsKey(update.payloadId) || update.payloadId == expected
            if (!isFile) return
            when (update.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS -> {
                    if (update.totalBytes > 0) {
                        progress.isIndeterminate = false
                        progress.progress = (100 * update.bytesTransferred / update.totalBytes).toInt()
                    }
                }
                PayloadTransferUpdate.Status.SUCCESS -> {
                    val payload = files.remove(update.payloadId) ?: return
                    handler.removeCallbacks(timeout)
                    saveAndShow(id, payload)
                }
                PayloadTransferUpdate.Status.FAILURE,
                PayloadTransferUpdate.Status.CANCELED -> fail(getString(R.string.recv_error))
            }
        }
    }

    private fun saveAndShow(endpointId: String, payload: Payload) {
        done = true
        val pfd = payload.asFile()?.asParcelFileDescriptor() ?: return fail(getString(R.string.recv_error))
        val m = meta ?: MediaUtils.Meta("photo_${System.currentTimeMillis()}.jpg", "image/jpeg", -1L)
        io.execute {
            val uri = MediaUtils.saveToGallery(this, pfd, m)
            val bitmap = uri?.let { MediaUtils.loadBitmap(this, it) }
            runOnUiThread {
                client.disconnectFromEndpoint(endpointId)
                if (uri == null || bitmap == null) {
                    fail(getString(R.string.recv_error))
                } else {
                    savedUri = uri
                    image.setImageBitmap(bitmap)
                    playArrival(uri, m.mime)
                }
            }
        }
    }

    // ---------- Animation d'arrivée ----------

    private fun playArrival(uri: Uri, mime: String) {
        progress.visibility = View.INVISIBLE
        val drop = resources.displayMetrics.heightPixels * 0.6f
        card.visibility = View.VISIBLE
        card.translationY = -drop
        card.scaleX = 0.7f
        card.scaleY = 0.7f
        card.alpha = 0f
        card.animate()
            .translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
            .setInterpolator(OvershootInterpolator(0.8f))
            .setDuration(700)
            .start()

        // Flou → net pendant l'arrivée (Android 12+)
        if (Build.VERSION.SDK_INT >= 31) {
            ValueAnimator.ofFloat(40f, 0.1f).apply {
                duration = 700
                addUpdateListener {
                    val r = it.animatedValue as Float
                    card.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
                }
                doOnEndCompat { card.setRenderEffect(null) }
                start()
            }
        }

        glow.stopPulse()
        glow.setIntensity(0.35f, 900)
        status.text = getString(R.string.recv_done)
        buttons.visibility = View.VISIBLE
        btnOpen.visibility = View.VISIBLE
        btnOpen.text = getString(R.string.btn_open)
        btnOpen.setOnClickListener {
            val view = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try {
                startActivity(view)
            } catch (_: Exception) {
            }
        }
    }

    private fun fail(message: String) {
        handler.removeCallbacks(timeout)
        try {
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (_: Exception) {
        }
        glow.stopPulse()
        glow.setIntensity(0f)
        progress.visibility = View.INVISIBLE
        status.text = message
        buttons.visibility = View.VISIBLE
        btnOpen.visibility = View.GONE
    }

    private inline fun ValueAnimator.doOnEndCompat(crossinline action: () -> Unit) {
        addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) = action()
        })
    }
}
