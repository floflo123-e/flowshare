package com.flowshare.app

import android.app.Activity
import android.content.ComponentName
import android.nfc.NfcAdapter
import android.nfc.cardemulation.CardEmulation
import android.os.Build

/**
 * Réglages NFC pendant que l'écran d'envoi est affiché :
 *  - notre service est prioritaire pour répondre,
 *  - (Android 15+) le téléphone qui envoie arrête de "lire" pour ne faire que "répondre",
 *    ce qui évite que les deux téléphones essaient de se lire en même temps.
 */
object NfcModes {

    fun enterSendMode(activity: Activity) {
        val adapter = NfcAdapter.getDefaultAdapter(activity) ?: return
        try {
            CardEmulation.getInstance(adapter).setPreferredService(
                activity, ComponentName(activity, FlowHceService::class.java)
            )
        } catch (_: Throwable) {
        }
        if (Build.VERSION.SDK_INT >= 35) {
            try {
                val cls = NfcAdapter::class.java
                val readerDisable = cls.getField("FLAG_READER_DISABLE").getInt(null)
                val listenKeep = cls.getField("FLAG_LISTEN_KEEP").getInt(null)
                cls.getMethod(
                    "setDiscoveryTechnology",
                    Activity::class.java,
                    Int::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType
                ).invoke(adapter, activity, readerDisable, listenKeep)
            } catch (_: Throwable) {
            }
        }
    }

    fun exitSendMode(activity: Activity) {
        val adapter = NfcAdapter.getDefaultAdapter(activity) ?: return
        try {
            CardEmulation.getInstance(adapter).unsetPreferredService(activity)
        } catch (_: Throwable) {
        }
        if (Build.VERSION.SDK_INT >= 35) {
            try {
                NfcAdapter::class.java
                    .getMethod("resetDiscoveryTechnology", Activity::class.java)
                    .invoke(adapter, activity)
            } catch (_: Throwable) {
            }
        }
    }
}
