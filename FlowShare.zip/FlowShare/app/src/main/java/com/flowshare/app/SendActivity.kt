package com.flowshare.app

import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import kotlin.math.abs

/**
 * La visionneuse de photo. Trois façons d'arriver ici :
 *  - depuis la galerie FlowShare (swipe gauche/droite entre les photos),
 *  - via "Partager › FlowShare" ou "Ouvrir avec" depuis une autre app,
 *  - automatiquement depuis la Galerie Samsung, quand le service d'accessibilité
 *    a appuyé sur Partager à ta place : l'envoi part tout de suite (mode auto).
 *
 * Tant qu'elle est affichée, coller un autre téléphone envoie la photo.
 */
class SendActivity : ComponentActivity(), SenderEngine.Listener {

    private lateinit var photo: ImageView
    private lateinit var scrim: View
    private lateinit var glow: GlowEdgeView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnChange: Button

    private var photoUri: Uri? = null
    private var auto = false
    private var galleryIndex = -1
    private var askedPermissions = false
    private val handler = Handler(Looper.getMainLooper())

    private val pickPhoto =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) showPhoto(uri) else if (photoUri == null) finish()
        }

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (Permissions.allGranted(this)) armIfPossible()
            else status.text = getString(R.string.status_perm_missing)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_send)
        photo = findViewById(R.id.photo)
        scrim = findViewById(R.id.scrim)
        glow = findViewById(R.id.glow)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        btnChange = findViewById(R.id.btnChange)
        btnChange.setOnClickListener { launchPicker() }

        val gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (abs(vx) > abs(vy) && abs(vx) > 600) {
                    step(if (vx < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        photo.setOnTouchListener { _, ev -> gestures.onTouchEvent(ev) }

        handleIntent(intent, allowPicker = savedInstanceState == null)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent, allowPicker = false)
    }

    override fun onResume() {
        super.onResume()
        SenderEngine.addListener(this)
        if (auto) {
            render(SenderEngine.state, 0f, null)
        } else {
            NfcModes.enterSendMode(this)
            armIfPossible()
        }
    }

    override fun onPause() {
        super.onPause()
        SenderEngine.removeListener(this)
        if (!auto) {
            NfcModes.exitSendMode(this)
            SenderEngine.disarm(SenderEngine.Source.IN_APP)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    // ---------- Entrées ----------

    private fun handleIntent(intent: Intent?, allowPicker: Boolean) {
        val index = intent?.getIntExtra(EXTRA_GALLERY_INDEX, -1) ?: -1
        if (index >= 0 && index < GalleryHolder.ids.size) {
            auto = false
            galleryIndex = index
            btnChange.visibility = View.GONE
            showPhoto(uriForId(GalleryHolder.ids[index]))
            return
        }

        val uri = extractUri(intent)
        if (uri != null) {
            galleryIndex = -1
            if (SenderEngine.awaitingGalleryUri) {
                // Partage déclenché par le service d'accessibilité : on envoie directement.
                auto = true
                btnChange.visibility = View.GONE
                showPhoto(uri)
                SenderEngine.provideUri(uri)
                render(SenderEngine.state, 0f, null)
            } else {
                auto = false
                btnChange.visibility = View.VISIBLE
                showPhoto(uri)
            }
            return
        }
        if (allowPicker) launchPicker()
    }

    private fun extractUri(intent: Intent?): Uri? = when (intent?.action) {
        Intent.ACTION_SEND ->
            if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        Intent.ACTION_VIEW -> intent.data
        else -> null
    }

    private fun launchPicker() {
        pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    private fun uriForId(id: Long): Uri =
        ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)

    private fun showPhoto(uri: Uri) {
        photoUri = uri
        photo.setImageBitmap(MediaUtils.loadBitmap(this, uri))
        resetVisuals()
        if (!auto && lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            if (SenderEngine.state == SenderEngine.State.ARMED && SenderEngine.source == SenderEngine.Source.IN_APP) {
                SenderEngine.provideUri(uri)
            } else {
                armIfPossible()
            }
        }
    }

    /** Swipe entre les photos de la galerie FlowShare. */
    private fun step(delta: Int) {
        if (galleryIndex < 0 || SenderEngine.isBusy) return
        val next = galleryIndex + delta
        if (next < 0 || next >= GalleryHolder.ids.size) return
        galleryIndex = next
        val out = if (delta > 0) -photo.width.toFloat() else photo.width.toFloat()
        photo.animate().translationX(out).alpha(0f).setDuration(120).withEndAction {
            showPhoto(uriForId(GalleryHolder.ids[next]))
            photo.translationX = -out
            photo.animate().translationX(0f).alpha(1f).setDuration(160).start()
        }.start()
    }

    private fun armIfPossible() {
        val uri = photoUri ?: return
        if (!Permissions.allGranted(this)) {
            if (!askedPermissions) {
                askedPermissions = true
                askPermissions.launch(Permissions.required())
            } else {
                status.text = getString(R.string.status_perm_missing)
            }
            return
        }
        if (SenderEngine.state == SenderEngine.State.IDLE || SenderEngine.state == SenderEngine.State.ARMED) {
            SenderEngine.arm(uri, SenderEngine.Source.IN_APP)
        }
    }

    // ---------- Animations ----------

    override fun onEngineUpdate(state: SenderEngine.State, progress: Float, message: String?) {
        render(state, progress, message)
    }

    private fun render(state: SenderEngine.State, fraction: Float, message: String?) {
        when (state) {
            SenderEngine.State.IDLE -> {
                if (!auto) {
                    resetVisuals()
                    if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) armIfPossible()
                }
            }
            SenderEngine.State.ARMED -> if (!auto) resetVisuals()
            SenderEngine.State.CONNECTING -> touchedVisuals(indeterminate = true)
            SenderEngine.State.SENDING -> {
                touchedVisuals(indeterminate = false)
                progress.progress = (fraction * 100).toInt()
                // La photo glisse vers le bord en contact pendant le transfert.
                photo.translationY = -fraction * photo.height * 0.5f
                photo.alpha = 1f - 0.5f * fraction
                status.text = getString(R.string.send_sending)
            }
            SenderEngine.State.DONE -> {
                sentVisuals()
                if (auto) handler.postDelayed({ finish() }, 1400)
            }
            SenderEngine.State.FAILED -> {
                resetVisuals()
                status.text = message ?: getString(R.string.send_error)
                if (auto) handler.postDelayed({ finish() }, 2200)
            }
        }
    }

    private fun touchedVisuals(indeterminate: Boolean) {
        if (scrim.alpha < 0.5f) {
            scrim.animate().alpha(0.55f).setDuration(400).start()
            photo.animate().scaleX(0.86f).scaleY(0.86f).setDuration(400).start()
            glow.setIntensity(1f)
            glow.startPulse()
        }
        status.text = getString(R.string.send_touch)
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = indeterminate
    }

    private fun sentVisuals() {
        status.text = getString(R.string.send_done)
        progress.isIndeterminate = false
        progress.progress = 100
        photo.animate()
            .translationY(-photo.height * 1.2f)
            .alpha(0f)
            .setInterpolator(AccelerateInterpolator())
            .setDuration(350)
            .start()
        glow.stopPulse()
        glow.setIntensity(0f, 900)
    }

    private fun resetVisuals() {
        photo.animate().cancel()
        photo.translationY = 0f
        photo.translationX = 0f
        photo.alpha = 1f
        photo.scaleX = 1f
        photo.scaleY = 1f
        scrim.animate().alpha(0f).setDuration(250).start()
        glow.stopPulse()
        glow.setIntensity(0f, 250)
        progress.visibility = View.INVISIBLE
        progress.progress = 0
        status.text = getString(R.string.send_hint)
    }

    companion object {
        const val EXTRA_GALLERY_INDEX = "com.flowshare.app.GALLERY_INDEX"
    }
}

/** Liste des photos de la galerie FlowShare, partagée avec la visionneuse. */
object GalleryHolder {
    var ids: LongArray = LongArray(0)
}
