package com.flowshare.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.nfc.NfcAdapter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** Réglages : autorisations, NFC, Bluetooth, accessibilité, sensibilité du rapprochement. */
class SetupActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var btnPermissions: Button
    private lateinit var btnNfc: Button
    private lateinit var btnBluetooth: Button
    private lateinit var btnAccessibility: Button
    private lateinit var btnRestricted: Button
    private lateinit var sensitivityLabel: TextView
    private lateinit var liveSignal: TextView
    private lateinit var seek: SeekBar

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            updateLiveSignal()
            handler.postDelayed(this, 500)
        }
    }

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)
        status = findViewById(R.id.status)
        btnPermissions = findViewById(R.id.btnPermissions)
        btnNfc = findViewById(R.id.btnNfc)
        btnBluetooth = findViewById(R.id.btnBluetooth)
        btnAccessibility = findViewById(R.id.btnAccessibility)
        btnRestricted = findViewById(R.id.btnRestricted)
        sensitivityLabel = findViewById(R.id.sensitivityLabel)
        liveSignal = findViewById(R.id.liveSignal)
        seek = findViewById(R.id.seekSensitivity)

        btnPermissions.setOnClickListener { askPermissions.launch(Permissions.required()) }
        btnNfc.setOnClickListener { open(Settings.ACTION_NFC_SETTINGS) }
        btnBluetooth.setOnClickListener { open(Settings.ACTION_BLUETOOTH_SETTINGS) }
        btnAccessibility.setOnClickListener { open(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        btnRestricted.setOnClickListener {
            open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        }

        // La barre va de "peu sensible" (il faut vraiment coller) à "très sensible".
        seek.max = Prefs.MAX_RSSI - Prefs.MIN_RSSI
        seek.progress = Prefs.MAX_RSSI - Prefs.rssiThreshold(this)
        updateSensitivityLabel()
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) {
                if (fromUser) {
                    Prefs.setRssiThreshold(this@SetupActivity, Prefs.MAX_RSSI - value)
                    updateSensitivityLabel()
                }
            }

            override fun onStartTrackingTouch(bar: SeekBar) {}
            override fun onStopTrackingTouch(bar: SeekBar) {}
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    private fun open(action: String, target: Uri? = null) {
        try {
            val intent = Intent(action)
            if (target != null) intent.data = target
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun refresh() {
        val nfc = NfcAdapter.getDefaultAdapter(this)
        val perms = Permissions.allGranted(this)
        val nfcOn = nfc?.isEnabled == true
        val btOn = BleProximity.isBluetoothOn(this)
        val a11y = FlowAccessibilityService.isEnabled(this)

        btnPermissions.visibility = if (perms) View.GONE else View.VISIBLE
        btnNfc.visibility = if (nfc != null && !nfcOn) View.VISIBLE else View.GONE
        btnBluetooth.visibility = if (btOn) View.GONE else View.VISIBLE
        btnAccessibility.visibility = if (a11y) View.GONE else View.VISIBLE
        btnRestricted.visibility = if (a11y) View.GONE else View.VISIBLE

        status.text = buildString {
            appendLine(line(perms, getString(R.string.check_perms)))
            appendLine(
                when {
                    nfc == null -> "✗ " + getString(R.string.check_no_nfc)
                    else -> line(nfcOn, getString(R.string.check_nfc))
                }
            )
            appendLine(line(btOn, getString(R.string.check_bt)))
            append(line(a11y, getString(R.string.check_a11y)))
        }
    }

    private fun line(ok: Boolean, label: String) = (if (ok) "✓ " else "✗ ") + label

    private fun updateSensitivityLabel() {
        sensitivityLabel.text = getString(R.string.sensitivity_value, Prefs.rssiThreshold(this))
    }

    private fun updateLiveSignal() {
        val rssi = BleProximity.lastRssi
        val age = SystemClock.elapsedRealtime() - BleProximity.lastSeenAt
        liveSignal.text = if (rssi != null && age < 3000) {
            getString(R.string.live_signal, rssi)
        } else {
            getString(R.string.live_signal_none)
        }
    }

    companion object {
        fun isReady(context: Context): Boolean =
            Permissions.allGranted(context) &&
                    BleProximity.isBluetoothOn(context) &&
                    FlowAccessibilityService.isEnabled(context)
    }
}
