package com.flowshare.app

import android.content.Context

object Prefs {
    private const val FILE = "flowshare"
    private const val KEY_RSSI = "rssi_threshold"
    const val DEFAULT_RSSI = -45
    const val MIN_RSSI = -75
    const val MAX_RSSI = -25

    @Volatile
    private var cached: Int? = null

    /** Signal Bluetooth minimum (dBm) pour considérer que les téléphones se touchent. */
    fun rssiThreshold(context: Context): Int =
        cached ?: context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getInt(KEY_RSSI, DEFAULT_RSSI).also { cached = it }

    fun setRssiThreshold(context: Context, value: Int) {
        cached = value
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt(KEY_RSSI, value).apply()
    }
}
