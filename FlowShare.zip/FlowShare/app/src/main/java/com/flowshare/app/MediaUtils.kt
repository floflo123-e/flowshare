package com.flowshare.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.FileInputStream
import java.io.IOException

object MediaUtils {

    data class Meta(val name: String, val mime: String, val size: Long)

    fun queryMeta(context: Context, uri: Uri): Meta {
        var name = "photo_${System.currentTimeMillis()}.jpg"
        var size = -1L
        try {
            context.contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Exception) {
        }
        val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
        return Meta(name, mime, size)
    }

    /** Charge une image réduite pour l'affichage (évite de saturer la mémoire). */
    fun loadBitmap(context: Context, uri: Uri, maxDim: Int = 2048): Bitmap? = try {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            val w = info.size.width
            val h = info.size.height
            val scale = maxOf(w, h).toFloat() / maxDim
            if (scale > 1f) {
                decoder.setTargetSize(
                    (w / scale).toInt().coerceAtLeast(1),
                    (h / scale).toInt().coerceAtLeast(1)
                )
            }
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } catch (_: Exception) {
        null
    }

    /** Copie le fichier reçu dans Galerie › Pictures/FlowShare. */
    fun saveToGallery(context: Context, pfd: ParcelFileDescriptor, meta: Meta): Uri? {
        val resolver = context.contentResolver
        val mime = if (meta.mime.startsWith("image/")) meta.mime else "image/jpeg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, meta.name)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FlowShare")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = resolver.insert(collection, values) ?: run { pfd.close(); return null }
        return try {
            FileInputStream(pfd.fileDescriptor).use { input ->
                val out = resolver.openOutputStream(uri) ?: throw IOException("Pas de flux de sortie")
                out.use { input.copyTo(it) }
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (_: Exception) {
            resolver.delete(uri, null, null)
            null
        } finally {
            try { pfd.close() } catch (_: Exception) {}
        }
    }
}
