package com.flowshare.app

import android.app.Application

class FlowApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SenderEngine.init(this)
    }
}
