package com.flowshare.app

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.AttributeSet
import android.util.LruCache
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

/**
 * La galerie FlowShare : toutes tes photos. Touche une photo pour l'ouvrir,
 * puis colle ton téléphone contre un autre : elle part.
 */
class MainActivity : ComponentActivity() {

    private lateinit var banner: TextView
    private lateinit var btnPhotos: Button
    private lateinit var grid: RecyclerView

    private val ids = ArrayList<Long>()
    private val io = Executors.newFixedThreadPool(3)
    private val cache = object : LruCache<Long, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()
    ) {
        override fun sizeOf(key: Long, value: Bitmap) = value.byteCount / 1024
    }

    private val askPhotos =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        banner = findViewById(R.id.banner)
        btnPhotos = findViewById(R.id.btnPhotos)
        grid = findViewById(R.id.grid)

        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }
        banner.setOnClickListener { startActivity(Intent(this, SetupActivity::class.java)) }
        btnPhotos.setOnClickListener { askPhotos.launch(photoPermissions()) }

        grid.layoutManager = GridLayoutManager(this, 3)
        grid.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdownNow()
    }

    private fun refresh() {
        banner.visibility = if (SetupActivity.isReady(this)) View.GONE else View.VISIBLE
        if (hasPhotoAccess()) {
            btnPhotos.visibility = View.GONE
            grid.visibility = View.VISIBLE
            loadPhotos()
        } else {
            btnPhotos.visibility = View.VISIBLE
            grid.visibility = View.GONE
        }
    }

    private fun photoPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
        )
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun hasPhotoAccess(): Boolean = photoPermissions().any {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadPhotos() {
        io.execute {
            val found = ArrayList<Long>()
            try {
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Images.Media._ID),
                    null, null,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    val col = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    while (c.moveToNext()) found.add(c.getLong(col))
                }
            } catch (_: Exception) {
            }
            runOnUiThread {
                ids.clear()
                ids.addAll(found)
                GalleryHolder.ids = found.toLongArray()
                adapter.notifyDataSetChanged()
            }
        }
    }

    private class Holder(val image: ImageView) : RecyclerView.ViewHolder(image)

    private val adapter = object : RecyclerView.Adapter<Holder>() {
        override fun getItemCount() = ids.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val view = SquareImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setPadding(2, 2, 2, 2)
                setBackgroundColor(0xFF0E1020.toInt())
            }
            return Holder(view)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val id = ids[position]
            holder.image.tag = id
            holder.image.setOnClickListener {
                GalleryHolder.ids = ids.toLongArray()
                startActivity(
                    Intent(this@MainActivity, SendActivity::class.java)
                        .putExtra(SendActivity.EXTRA_GALLERY_INDEX, holder.bindingAdapterPosition)
                )
            }
            val cached = cache.get(id)
            if (cached != null) {
                holder.image.setImageBitmap(cached)
                return
            }
            holder.image.setImageDrawable(null)
            io.execute {
                val bmp = try {
                    contentResolver.loadThumbnail(
                        ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                        Size(320, 320), null
                    )
                } catch (_: Exception) {
                    null
                }
                if (bmp != null) {
                    cache.put(id, bmp)
                    runOnUiThread { if (holder.image.tag == id) holder.image.setImageBitmap(bmp) }
                }
            }
        }
    }
}

/** Case carrée de la grille. */
class SquareImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ImageView(context, attrs) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec)
    }
}
