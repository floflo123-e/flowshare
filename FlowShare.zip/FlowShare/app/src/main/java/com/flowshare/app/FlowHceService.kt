package com.flowshare.app

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.cardemulation.HostApduService
import android.os.Bundle

/**
 * Le téléphone qui envoie émule une puce NFC "Type 4" contenant un petit message :
 *  - un code de session (token) pour retrouver ce téléphone via Nearby,
 *  - un "Android Application Record" qui fait ouvrir FlowShare sur l'autre téléphone,
 *    même si l'app y est fermée.
 *
 * Le service ne répond que lorsqu'une photo est prête à être envoyée ;
 * le reste du temps il reste muet et ne gêne pas le paiement sans contact.
 */
class FlowHceService : HostApduService() {

    private var selectedFile = FILE_NONE
    private var ndefFile: ByteArray? = null
    private var notified = false

    override fun processCommandApdu(apdu: ByteArray, extras: Bundle?): ByteArray {
        if (apdu.size < 4) return SW_INS_NOT_SUPPORTED
        val ins = apdu[1].toInt() and 0xFF
        val p1 = apdu[2].toInt() and 0xFF
        val p2 = apdu[3].toInt() and 0xFF
        return when (ins) {
            0xA4 -> handleSelect(apdu, p1)
            0xB0 -> handleReadBinary(apdu, p1, p2)
            else -> SW_INS_NOT_SUPPORTED
        }
    }

    private fun handleSelect(apdu: ByteArray, p1: Int): ByteArray {
        if (apdu.size < 5) return SW_NOT_FOUND
        val lc = apdu[4].toInt() and 0xFF
        if (apdu.size < 5 + lc) return SW_NOT_FOUND
        val data = apdu.copyOfRange(5, 5 + lc)

        // SELECT par AID (application NDEF)
        if (p1 == 0x04) {
            if (!data.contentEquals(NDEF_AID)) return SW_NOT_FOUND
            val token = ShareSession.token ?: return SW_NOT_FOUND
            ndefFile = buildNdefFile(token)
            selectedFile = FILE_NONE
            notified = false
            return SW_OK
        }

        // SELECT par identifiant de fichier (CC ou NDEF)
        if (p1 == 0x00 && ndefFile != null) {
            selectedFile = when {
                data.contentEquals(CC_FILE_ID) -> FILE_CC
                data.contentEquals(NDEF_FILE_ID) -> FILE_NDEF
                else -> return SW_NOT_FOUND
            }
            return SW_OK
        }
        return SW_NOT_FOUND
    }

    private fun handleReadBinary(apdu: ByteArray, p1: Int, p2: Int): ByteArray {
        val file = when (selectedFile) {
            FILE_CC -> CC_FILE
            FILE_NDEF -> ndefFile ?: return SW_NOT_FOUND
            else -> return SW_NOT_FOUND
        }
        val offset = (p1 shl 8) or p2
        var le = if (apdu.size >= 5) apdu[4].toInt() and 0xFF else 0
        if (le == 0) le = 256
        if (offset > file.size) return SW_WRONG_PARAMS
        val end = minOf(file.size, offset + le)

        // Dès que l'autre téléphone lit le contenu, on lance l'animation côté envoi.
        if (selectedFile == FILE_NDEF && end > 2 && !notified) {
            notified = true
            ShareSession.notifyTouched()
        }
        return file.copyOfRange(offset, end) + SW_OK
    }

    override fun onDeactivated(reason: Int) {
        selectedFile = FILE_NONE
    }

    private fun buildNdefFile(token: String): ByteArray {
        val message = NdefMessage(
            NdefRecord.createMime(ShareSession.MIME_TOKEN, token.toByteArray(Charsets.UTF_8)),
            NdefRecord.createApplicationRecord(packageName)
        ).toByteArray()
        val n = message.size
        return byteArrayOf((n shr 8).toByte(), n.toByte()) + message
    }

    companion object {
        private const val FILE_NONE = 0
        private const val FILE_CC = 1
        private const val FILE_NDEF = 2

        private val NDEF_AID = hex("D2760000850101")
        private val CC_FILE_ID = hex("E103")
        private val NDEF_FILE_ID = hex("E104")

        // Capability Container : version 2.0, lecture par blocs de 127 octets,
        // fichier NDEF E104 de 4 Ko max, lecture libre, écriture interdite.
        private val CC_FILE = hex("000F20007F007F0406E104100000FF")

        private val SW_OK = hex("9000")
        private val SW_NOT_FOUND = hex("6A82")
        private val SW_WRONG_PARAMS = hex("6B00")
        private val SW_INS_NOT_SUPPORTED = hex("6D00")

        private fun hex(s: String): ByteArray =
            ByteArray(s.length / 2) { i -> s.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }
}
