package com.flowshare.app

import android.os.Handler
import android.os.Looper
import java.security.SecureRandom

/**
 * Code de session partagé entre le moteur d'envoi, le service NFC et le Bluetooth.
 * Tant qu'un [token] existe, le téléphone "répond" quand on l'approche d'un autre.
 */
object ShareSession {
    const val MIME_TOKEN = "application/vnd.com.flowshare.token"
    const val SERVICE_ID = "com.flowshare.app.transfer"
    const val EXTRA_TOKEN = "com.flowshare.app.TOKEN"

    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private val random = SecureRandom()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var token: String? = null
        private set

    fun start(): String {
        val t = buildString { repeat(8) { append(ALPHABET[random.nextInt(ALPHABET.length)]) } }
        token = t
        return t
    }

    fun stop() {
        token = null
    }

    /** Appelé par le service NFC quand un autre téléphone vient de nous lire. */
    fun notifyTouched() {
        main.post { SenderEngine.onTouched() }
    }

    fun senderName(token: String) = "FS-$token"
    fun receiverName(token: String) = "FSR-$token"
}
