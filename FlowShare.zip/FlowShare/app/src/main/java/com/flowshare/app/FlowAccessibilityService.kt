package com.flowshare.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * Le "pont" vers la Galerie Samsung (et d'autres galeries).
 *
 *  1. Il repère quand une photo est ouverte en plein écran (le bouton "Partager" est visible)
 *     et prépare l'envoi : NFC + Bluetooth actifs.
 *  2. Quand on colle un autre téléphone, il appuie lui-même sur Partager › FlowShare :
 *     la vraie photo (pleine qualité) arrive dans FlowShare et part aussitôt.
 *  3. Côté réception, il écoute le Bluetooth en permanence (écran allumé) et ouvre
 *     FlowShare tout seul quand un téléphone qui envoie est collé.
 *
 * Un service d'accessibilité reste actif sans notification permanente.
 */
class FlowAccessibilityService : AccessibilityService(), SenderEngine.Listener {

    private val handler = Handler(Looper.getMainLooper())
    private var galleryArmed = false

    // Automatisation du menu Partager
    private var autoActive = false
    private var autoStartedAt = 0L
    private var lastScrollAt = 0L
    private var scrollTries = 0

    // Évite d'ouvrir deux fois la réception pour le même envoi
    private val recentTokens = HashMap<String, Long>()

    private val evaluate = Runnable { evaluateForeground() }
    private val autoStep = Runnable { stepAutoShare() }
    private val autoTimeout = Runnable { stopAutoShare(success = false) }

    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> BleProximity.stopScan(this@FlowAccessibilityService)
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> startScanIfPossible()
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val s = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    if (s == BluetoothAdapter.STATE_ON) startScanIfPossible()
                    else if (s == BluetoothAdapter.STATE_OFF) BleProximity.stopScan(this@FlowAccessibilityService)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        ContextCompat.registerReceiver(this, systemReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        SenderEngine.addListener(this)
        SenderEngine.shareTrigger = { startAutoShare() }
        BleProximity.onProximity = { token -> onProximity(token) }
        startScanIfPossible()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(systemReceiver)
        } catch (_: Exception) {
        }
        SenderEngine.removeListener(this)
        SenderEngine.shareTrigger = null
        BleProximity.onProximity = null
        BleProximity.stopScan(this)
        if (galleryArmed) SenderEngine.disarm(SenderEngine.Source.GALLERY)
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (autoActive) {
            handler.removeCallbacks(autoStep)
            handler.postDelayed(autoStep, 200)
            return
        }
        if (pkg == packageName) return
        if (pkg !in GALLERY_PACKAGES && !galleryArmed) return
        handler.removeCallbacks(evaluate)
        handler.postDelayed(evaluate, 300)
    }

    override fun onEngineUpdate(state: SenderEngine.State, progress: Float, message: String?) {
        if (state == SenderEngine.State.IDLE) {
            galleryArmed = false
            handler.removeCallbacks(evaluate)
            handler.postDelayed(evaluate, 500)
        }
        if (state == SenderEngine.State.FAILED && autoActive) stopAutoShare(success = false, silent = true)
    }

    // ---------- 1. Repérer une photo ouverte dans la Galerie ----------

    private fun evaluateForeground() {
        if (autoActive) return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName) return
        val viewerOpen = pkg in GALLERY_PACKAGES && findShareButton(root) != null
        if (viewerOpen && !galleryArmed) {
            if (SenderEngine.state == SenderEngine.State.IDLE || SenderEngine.source == SenderEngine.Source.GALLERY) {
                galleryArmed = SenderEngine.arm(null, SenderEngine.Source.GALLERY)
            }
        } else if (!viewerOpen && galleryArmed) {
            galleryArmed = false
            SenderEngine.disarm(SenderEngine.Source.GALLERY)
        }
    }

    private fun findShareButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? =
        findNode(root) { node ->
            if (!node.isVisibleToUser) return@findNode false
            val label = (node.contentDescription ?: node.text)?.toString()?.trim() ?: return@findNode false
            SHARE_LABELS.any { it.equals(label, ignoreCase = true) }
        }

    // ---------- 2. Appuyer sur Partager › FlowShare ----------

    private fun startAutoShare() {
        val root = rootInActiveWindow
        val share = root?.let { findShareButton(it) }
        if (share == null || !click(share)) {
            SenderEngine.fail(getString(R.string.auto_no_share))
            return
        }
        autoActive = true
        autoStartedAt = SystemClock.elapsedRealtime()
        lastScrollAt = 0L
        scrollTries = 0
        handler.postDelayed(autoStep, 500)
        handler.postDelayed(autoTimeout, 7000)
    }

    private fun stepAutoShare() {
        if (!autoActive) return
        val target = findInAllWindows { node ->
            node.packageName?.toString() != packageName &&
                    ((node.text?.toString()?.contains(TARGET_LABEL, ignoreCase = true) == true) ||
                            (node.contentDescription?.toString()?.contains(TARGET_LABEL, ignoreCase = true) == true))
        }
        if (target != null && click(target)) {
            stopAutoShare(success = true)
            return
        }
        // FlowShare n'est pas visible dans le menu : on fait défiler la liste des apps.
        val now = SystemClock.elapsedRealtime()
        if (now - autoStartedAt > 1200 && now - lastScrollAt > 700 && scrollTries < 6) {
            lastScrollAt = now
            scrollTries++
            rootInActiveWindow?.let { root ->
                findNode(root) { it.isScrollable && it.isVisibleToUser }
                    ?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            }
        }
        handler.postDelayed(autoStep, 400)
    }

    private fun stopAutoShare(success: Boolean, silent: Boolean = false) {
        if (!autoActive) return
        autoActive = false
        handler.removeCallbacks(autoStep)
        handler.removeCallbacks(autoTimeout)
        if (!success && !silent) {
            Toast.makeText(this, R.string.auto_not_found, Toast.LENGTH_LONG).show()
            SenderEngine.fail(getString(R.string.auto_not_found))
        }
    }

    // ---------- 3. Réception déclenchée par le Bluetooth ----------

    private fun startScanIfPossible() {
        val power = getSystemService(PowerManager::class.java)
        if (power?.isInteractive == true) BleProximity.startScan(this)
    }

    private fun onProximity(token: String) {
        // Ce téléphone a lui-même une photo prête : c'est lui qui envoie, pas lui qui reçoit.
        if (SenderEngine.state != SenderEngine.State.IDLE) return
        val keyguard = getSystemService(KeyguardManager::class.java)
        if (keyguard?.isKeyguardLocked == true) return
        val now = SystemClock.elapsedRealtime()
        recentTokens.entries.removeAll { now - it.value > 60_000 }
        if (recentTokens.containsKey(token)) return
        recentTokens[token] = now
        val intent = Intent(this, ReceiveActivity::class.java)
            .putExtra(ShareSession.EXTRA_TOKEN, token)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (_: Exception) {
        }
    }

    // ---------- Outils ----------

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        // Plan B : un vrai "tap" au centre de l'élément.
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun findInAllWindows(match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val roots = try {
            windows.mapNotNull { it.root }
        } catch (_: Exception) {
            emptyList()
        }
        for (root in roots) findNode(root, match)?.let { return it }
        return rootInActiveWindow?.let { findNode(it, match) }
    }

    private fun findNode(
        root: AccessibilityNodeInfo,
        match: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 1500) {
            val node = queue.removeFirst()
            visited++
            if (match(node)) return node
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        return null
    }

    companion object {
        private const val TARGET_LABEL = "FlowShare"

        val GALLERY_PACKAGES = setOf(
            "com.sec.android.gallery3d",          // Galerie Samsung
            "com.google.android.apps.photos",     // Google Photos
            "com.miui.gallery",                   // Xiaomi
            "com.coloros.gallery3d",              // Oppo / OnePlus
            "com.oneplus.gallery",
            "com.vivo.gallery",
            "com.huawei.photos"
        )

        private val SHARE_LABELS = listOf(
            "Partager", "Share", "Compartir", "Teilen", "Condividi", "Partilhar", "Delen"
        )

        fun isEnabled(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val me = ComponentName(context, FlowAccessibilityService::class.java)
            return enabled.split(':').any {
                ComponentName.unflattenFromString(it) == me
            }
        }
    }
}
