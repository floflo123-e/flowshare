package com.flowshare.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * La lueur blanche/bleue qui apparaît sur le bord de l'écran,
 * comme dans la vidéo, avec une légère pulsation.
 */
class GlowEdgeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var intensity = 0f
    private var pulse = 0f
    private var intensityAnimator: ValueAnimator? = null
    private var pulseAnimator: ValueAnimator? = null

    fun setIntensity(target: Float, durationMs: Long = 450L) {
        intensityAnimator?.cancel()
        intensityAnimator = ValueAnimator.ofFloat(intensity, target).apply {
            duration = durationMs
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                intensity = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun startPulse() {
        if (pulseAnimator != null) return
        pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100L
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stopPulse() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        pulse = 0f
        invalidate()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        intensityAnimator?.cancel()
        pulseAnimator?.cancel()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (intensity <= 0.01f || width == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val radius = w * (0.8f + 0.15f * pulse) * (0.5f + 0.5f * intensity)
        val a = (intensity * (0.8f + 0.2f * pulse)).coerceIn(0f, 1f)
        paint.shader = RadialGradient(
            w / 2f, -radius * 0.2f, radius,
            intArrayOf(
                withAlpha(Color.WHITE, a),
                withAlpha(0xFF8FD3FF.toInt(), a * 0.75f),
                withAlpha(0xFF4B6BFF.toInt(), a * 0.3f),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.35f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, minOf(h, radius), paint)
    }

    private fun withAlpha(color: Int, alpha: Float): Int =
        Color.argb((255 * alpha).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
}
