package com.flowshare.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.ParcelUuid
import android.os.SystemClock

/**
 * Détection du rapprochement par Bluetooth Low Energy.
 *
 *  - Le téléphone qui a une photo prête diffuse un petit signal contenant le code de session.
 *  - Les autres téléphones écoutent. Quand le signal devient très fort (téléphones collés),
 *    on déclenche la réception.
 *
 * Fonctionne quelle que soit l'orientation (haut contre haut, dos à dos…),
 * contrairement au NFC qui exige d'aligner les antennes.
 */
@SuppressLint("MissingPermission")
object BleProximity {

    val SERVICE_UUID: ParcelUuid = ParcelUuid.fromString("0000F1A5-0000-1000-8000-00805F9B34FB")

    private const val HITS_NEEDED = 2
    private const val HIT_WINDOW_MS = 1500L

    private class Hit(var count: Int, var time: Long)

    private val hits = HashMap<String, Hit>()
    private var appContext: Context? = null
    private var scanning = false
    private var advertising = false

    /** Dernier signal FlowShare capté (pour l'écran de réglage de la sensibilité). */
    @Volatile
    var lastRssi: Int? = null
        private set

    @Volatile
    var lastSeenAt: Long = 0L
        private set

    /** Appelé sur le thread principal quand un téléphone qui envoie est collé au nôtre. */
    var onProximity: ((String) -> Unit)? = null

    private fun adapter(context: Context): BluetoothAdapter? =
        context.getSystemService(BluetoothManager::class.java)?.adapter

    fun isBluetoothOn(context: Context): Boolean = adapter(context)?.isEnabled == true

    // ---------- Diffusion (téléphone qui envoie) ----------

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartFailure(errorCode: Int) {
            advertising = false
        }
    }

    fun startAdvertising(context: Context, token: String) {
        stopAdvertising(context)
        val adapter = adapter(context) ?: return
        if (!adapter.isEnabled || !Permissions.allGranted(context)) return
        val advertiser = adapter.bluetoothLeAdvertiser ?: return
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(false)
            .setTimeout(0)
            .build()
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .setIncludeTxPowerLevel(false)
            .addServiceData(SERVICE_UUID, token.toByteArray(Charsets.US_ASCII))
            .build()
        try {
            advertiser.startAdvertising(settings, data, advertiseCallback)
            advertising = true
        } catch (_: Exception) {
            advertising = false
        }
    }

    fun stopAdvertising(context: Context) {
        if (!advertising) return
        advertising = false
        try {
            adapter(context)?.bluetoothLeAdvertiser?.stopAdvertising(advertiseCallback)
        } catch (_: Exception) {
        }
    }

    // ---------- Écoute (téléphone qui reçoit) ----------

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            handle(result)
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            results.forEach { handle(it) }
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
        }
    }

    fun startScan(context: Context) {
        if (scanning) return
        appContext = context.applicationContext
        val adapter = adapter(context) ?: return
        if (!adapter.isEnabled || !Permissions.allGranted(context)) return
        val scanner = adapter.bluetoothLeScanner ?: return
        val filter = ScanFilter.Builder()
            .setServiceData(SERVICE_UUID, ByteArray(0), ByteArray(0))
            .build()
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setReportDelay(0)
            .build()
        try {
            scanner.startScan(listOf(filter), settings, scanCallback)
            scanning = true
        } catch (_: Exception) {
            scanning = false
        }
    }

    fun stopScan(context: Context) {
        if (!scanning) return
        scanning = false
        hits.clear()
        try {
            adapter(context)?.bluetoothLeScanner?.stopScan(scanCallback)
        } catch (_: Exception) {
        }
    }

    private fun handle(result: ScanResult) {
        val data = result.scanRecord?.getServiceData(SERVICE_UUID) ?: return
        if (data.isEmpty()) return
        val token = String(data, Charsets.US_ASCII)
        val now = SystemClock.elapsedRealtime()
        lastRssi = result.rssi
        lastSeenAt = now

        val ctx = appContext ?: return
        if (result.rssi < Prefs.rssiThreshold(ctx)) {
            hits.remove(token)
            return
        }
        val hit = hits[token]
        if (hit != null && now - hit.time < HIT_WINDOW_MS) {
            hit.count++
            hit.time = now
        } else {
            hits[token] = Hit(1, now)
        }
        if ((hits[token]?.count ?: 0) >= HITS_NEEDED) {
            hits.remove(token)
            onProximity?.invoke(token)
        }
    }
}
