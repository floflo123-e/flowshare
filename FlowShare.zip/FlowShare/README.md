# FlowShare : envoyer une photo en collant deux téléphones Android

Tu ouvres une photo, dans la **Galerie Samsung** ou dans la galerie FlowShare, et tu
colles ton téléphone contre un autre Android qui a FlowShare. La photo passe d'un
écran à l'autre avec une lueur sur le bord, et l'autre téléphone **ouvre FlowShare
tout seul**. Il n'y a pas de notification permanente.

## Les trois briques

| Brique | Rôle |
|---|---|
| **Bluetooth** (BLE) | Détecte que les téléphones sont collés, **dans n'importe quel sens** (haut contre haut comme sur iPhone). Le téléphone qui a une photo ouverte émet un petit signal, l'autre déclenche quand le signal devient très fort. |
| **NFC** | Autre déclencheur, **dos à dos**. Il marche même si l'accessibilité n'est pas activée sur le téléphone qui reçoit. |
| **Nearby Connections** | Transfert de la photo en pleine qualité (Bluetooth + Wi-Fi direct, sans internet). C'est la même technologie que Quick Share. |

### Avec la Galerie Samsung
Le **service d'accessibilité** voit quand une photo est ouverte en plein écran (le
bouton « Partager » est visible). Quand tu colles un téléphone, il appuie à ta place
sur **Partager › FlowShare** : la photo d'origine part tout de suite et tu reviens
dans la Galerie.

### Avec la galerie FlowShare
Ouvre l'app : toutes tes photos s'affichent. Touche une photo, puis glisse à gauche
ou à droite pour changer de photo, et colle le téléphone. Cette option est la plus
fiable.

## Installation (sur les DEUX téléphones)

1. Installe l'APK.
2. Ouvre FlowShare et autorise **les photos** et **les appareils à proximité**.
3. ⚙ Réglages :
   - Active le **Bluetooth**, et le **NFC** si tu veux aussi le dos à dos.
   - Android 13 et plus, pour une APK installée hors Play Store : **Infos de
     l'appli FlowShare › ⋮ › Autoriser les paramètres restreints**. Sans ça, le
     bouton reste grisé à l'étape suivante.
   - **Accessibilité › Applications installées › FlowShare › Activer**.
4. Règle la **sensibilité**. Ouvre une photo sur l'autre téléphone, colle les deux
   téléphones et regarde la valeur « Signal capté ». Place la barre juste au-dessus
   de cette valeur. Plus la barre est à gauche, plus il faut coller les téléphones.

## Bon à savoir

- Le téléphone qui reçoit doit avoir l'**écran allumé et déverrouillé**.
- Si les deux téléphones ont une photo ouverte, aucun ne reçoit : chacun croit être
  celui qui envoie.
- **Astuce Galerie Samsung** : épingle FlowShare en haut du menu Partager
  (appui long sur l'icône › Épingler). L'automatisme le trouve alors au premier
  coup.
- Une mise à jour de la Galerie Samsung peut casser l'automatisme. La galerie
  FlowShare, elle, continue de marcher.
- L'écoute Bluetooth consomme un peu de batterie quand l'écran est allumé. Elle
  s'arrête écran éteint.
- Android seulement. Pour un iPhone, utilise Quick Share ↔ AirDrop, intégré aux
  Galaxy S24, S25 et S26.

## Obtenir l'APK sans ordinateur (via GitHub)

1. Crée un dépôt sur github.com et envoies-y le contenu de ce dossier.
2. L'onglet **Actions** › « Construire l'APK » se lance tout seul (5 min environ).
3. Ouvre le build terminé › **Artifacts** › `FlowShare-apk`, puis dézippe et
   installe `app-debug.apk`.

Avec Android Studio : ouvre le dossier puis clique sur ▶ Run. Android 10 minimum.

## Fichiers clés

| Fichier | Rôle |
|---|---|
| `SenderEngine.kt` | Moteur d'envoi (Nearby), indépendant des écrans |
| `BleProximity.kt` | Détection du rapprochement par Bluetooth |
| `FlowHceService.kt` | Détection par NFC (le téléphone imite une puce) |
| `FlowAccessibilityService.kt` | Pont avec la Galerie Samsung + écoute Bluetooth en fond |
| `MainActivity.kt` / `SendActivity.kt` | Galerie FlowShare et visionneuse |
| `ReceiveActivity.kt` | Réception et animation d'arrivée |
| `SetupActivity.kt` | Réglages et sensibilité |
